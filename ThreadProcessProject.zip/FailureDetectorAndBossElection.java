public class FailureDetectorAndBossElection extends Thread{
    
}
