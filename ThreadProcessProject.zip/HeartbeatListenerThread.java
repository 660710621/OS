public class HeartbeatListenerThread extends Thread{
    
}
